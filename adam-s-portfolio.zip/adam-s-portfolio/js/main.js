(() => {
  const fonts = [
    "Anton, sans-serif",
    "Bangers, cursive",
    "Black Ops One, system-ui",
    "Permanent Marker, cursive",
    "Oswald, sans-serif",
    "Teko, sans-serif",
    "Archivo Black, sans-serif",
    "Rock Salt, cursive",
  ];

  document.querySelectorAll("[data-ransom]").forEach((el) => {
    const text = el.dataset.ransom || "";
    el.innerHTML = "";
    [...text].forEach((ch, i) => {
      const b = document.createElement("b");
      b.textContent = ch;
      b.style.fontFamily = fonts[i % fonts.length];
      b.style.transform = `skewX(16deg) rotate(${(i % 3) - 1}deg)`;
      b.style.fontSize = `${1 + (i % 2) * 0.08}em`;
      el.appendChild(b);
    });
  });

  const cursor = document.querySelector(".cursor");
  const dot = document.querySelector(".cursor-dot");
  const fine = window.matchMedia("(pointer: fine)").matches;
  if (fine && cursor && dot) {
    let x = innerWidth / 2;
    let y = innerHeight / 2;
    let cx = x;
    let cy = y;
    window.addEventListener("mousemove", (e) => {
      x = e.clientX;
      y = e.clientY;
      dot.style.transform = `translate(${x}px, ${y}px) translate(-50%,-50%)`;
    });
    const loop = () => {
      cx += (x - cx) * 0.22;
      cy += (y - cy) * 0.22;
      cursor.style.transform = `translate(${cx}px, ${cy}px) translate(-50%,-50%) rotate(45deg)`;
      requestAnimationFrame(loop);
    };
    loop();
    document.querySelectorAll("a, button, .heist").forEach((el) => {
      el.addEventListener("mouseenter", () => cursor.classList.add("is-hot"));
      el.addEventListener("mouseleave", () => cursor.classList.remove("is-hot"));
    });
  }

  let audioCtx = null;
  let sfxOn = false;
  const sfxBtn = document.getElementById("sfxBtn");

  const beep = (freq = 420, dur = 0.07, type = "square", gain = 0.04) => {
    if (!sfxOn || !audioCtx) return;
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = type;
    o.frequency.value = freq;
    g.gain.value = gain;
    g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + dur);
    o.connect(g);
    g.connect(audioCtx.destination);
    o.start();
    o.stop(audioCtx.currentTime + dur);
  };

  const slashSfx = () => {
    beep(180, 0.12, "sawtooth", 0.05);
    setTimeout(() => beep(90, 0.16, "square", 0.04), 40);
  };

  sfxBtn?.addEventListener("click", () => {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    sfxOn = !sfxOn;
    sfxBtn.setAttribute("aria-pressed", String(sfxOn));
    sfxBtn.textContent = sfxOn ? "SFX ON" : "SFX OFF";
    beep(640, 0.08);
  });

  const slash = document.getElementById("slash");
  const boot = document.getElementById("boot");
  const views = [...document.querySelectorAll(".view")];
  const items = [...document.querySelectorAll(".menu-item")];
  let current = "home";
  let locked = false;

  const showView = (id) => {
    views.forEach((v) => v.classList.toggle("is-active", v.dataset.view === id));
    items.forEach((it) => it.classList.toggle("is-on", it.dataset.go === id));
    current = id;
    document.querySelector(".p5-menu")?.classList.remove("open");
    document.querySelector(".nav-burger")?.setAttribute("aria-expanded", "false");
  };

  const go = (id) => {
    if (locked || id === current) return;
    locked = true;
    slash.classList.remove("go");
    void slash.offsetWidth;
    slash.classList.add("go");
    slashSfx();
    setTimeout(() => showView(id), 220);
    setTimeout(() => {
      slash.classList.remove("go");
      locked = false;
    }, 620);
  };

  document.querySelectorAll("[data-go]").forEach((el) => {
    el.addEventListener("click", () => {
      beep(520, 0.05);
      go(el.dataset.go);
    });
  });

  const start = () => {
    if (!audioCtx) {
      try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch (_) {}
    }
    const flash = document.querySelector(".boot-flash");
    if (flash) {
      flash.style.transition = "opacity .12s";
      flash.style.opacity = "1";
      setTimeout(() => (flash.style.opacity = "0"), 80);
    }
    slash.classList.add("go");
    slashSfx();
    setTimeout(() => boot.classList.add("is-out"), 180);
    setTimeout(() => {
      boot.remove();
      slash.classList.remove("go");
    }, 700);
  };
  boot?.addEventListener("click", start);
  window.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && boot && document.body.contains(boot)) start();
  });

  document.querySelector(".nav-burger")?.addEventListener("click", () => {
    const menu = document.querySelector(".p5-menu");
    const open = menu.classList.toggle("open");
    document.querySelector(".nav-burger").setAttribute("aria-expanded", String(open));
    beep(300, 0.05);
  });

  document.querySelectorAll("[data-tilt]").forEach((card) => {
    card.addEventListener("mousemove", (e) => {
      const r = card.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      card.style.transform = `rotateX(${(-py * 8).toFixed(2)}deg) rotateY(${(px * 10).toFixed(2)}deg)`;
    });
    card.addEventListener("mouseleave", () => {
      card.style.transform = "";
    });
  });

  const burst = document.getElementById("burst");
  document.getElementById("attackBtn")?.addEventListener("click", () => {
    burst.innerHTML = "<b>ALL-OUT ATTACK</b>";
    burst.classList.remove("show");
    void burst.offsetWidth;
    burst.classList.add("show");
    beep(110, 0.2, "sawtooth", 0.07);
    setTimeout(() => beep(220, 0.12, "square", 0.06), 80);
    setTimeout(() => beep(440, 0.18, "sawtooth", 0.05), 160);
    document.body.animate(
      [{ filter: "contrast(1)" }, { filter: "contrast(1.6) saturate(1.4)" }, { filter: "none" }],
      { duration: 420 }
    );
  });

  window.addEventListener("keydown", (e) => {
    const map = { Digit1: "home", Digit2: "work", Digit3: "about", Digit4: "contact" };
    if (map[e.code]) go(map[e.code]);
  });
})();
