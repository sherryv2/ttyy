# ADAM S. — Persona-inspired portfolio

Website portofolio interaktif bergaya pop-punk (terinspirasi UI Persona 5, **bukan** aset resmi Atlus).

## Fitur
- Calling card boot screen
- Slash wipe antar halaman
- Menu miring ransom-note
- Custom cursor (desktop)
- Tilt 3D di kartu
- SFX opsional (Web Audio)
- Shortcut 1–4
- ALL-OUT ATTACK easter egg
- Responsive

Buka `index.html` di browser.
